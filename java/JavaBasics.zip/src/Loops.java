/**
 * Created by Amuri on 3/28/2018.
 */
public class Loops {
    public static void main(String [] args)
    {
        //lets implement the for-loop
        for(int x=0; x<=5; x++)
        {
            System.out.println("your for-loop"+x);
        }

        //lets use while loop
        int z=5;
        while(z>=0)
        {
            System.out.println("Your while loop"+z);
            z--;
        }
        //lets use do-while loop
        int y;
        y=0;
        do
        {
            System.out.println("Do-while loop"+y);
            y++;
        }while (y<=9);


    }
}
