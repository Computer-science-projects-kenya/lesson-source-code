/**
 * Created by Amuri on 3/28/2018.
 */
public class IfStatement {
    public static void main(String[] args)
    {
        int marks;
        marks=50;

        if(marks<=50)
        {
         System.out.println("You FAILED");
        }
        else if(marks>50)
        {
            System.out.println("You PASSED");
        }
    }
}
