/**
 * Created by Amuri on 3/28/2018.
 */
public class SwitchCase {
    public static void main(String[] args)
    {
        int month;
        month=5;

        switch (month)
        {
            case 1:
            {
                System.out.println("Month=JANUARY");
                break;
            }

            case 4:
            {
                System.out.println("Month=APRIL");
                break;
            }
            case 5:
            {
                System.out.println("Month=MAY");
                break;
            }
            default:
            {
                System.out.println("The Month is not listed");
            }
        }
    }
}
