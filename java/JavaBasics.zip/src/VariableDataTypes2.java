/**
 * Created by Amuri on 3/28/2018.
 */
public class VariableDataTypes2 {
    public static void main(String[] args)
    {
        double area,radius;
        double pi=3.17;
           radius=3.0;
        area=pi*radius*radius;
       System.out.println("Area is "+area);

    }
}
