/**
 * Created by Amuri on 3/27/2018.
 */
public class VariableDataTypes1 {
    public static void main(String[] args)
    {
        //declaration of variables----------this line is a comment
        int firstNumber;
        int secondNumber;
        int answer;

        //Initializing our variables with data------this line  is also a comment
        firstNumber=10;
        secondNumber=40;

        //performing the calculation----this line is also a comment
        answer=firstNumber+secondNumber;

        //displaying the output----that + sign is used to combine the text with
        //contents of variable 'answer'
        System.out.println("our answer is"+answer);


    }
}
