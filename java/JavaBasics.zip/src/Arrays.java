/**
 * Created by Amuri on 3/28/2018.
 */
public class Arrays {
    public static void  main(String [] args)
    {
        String[] employees={ "Amuri","Ryan","Reagan","wesley","Oscar","Jack"};

        //we can retrieve a sigle element
        System.out.println(employees[0]);

        //we can also retrieve all the elements
        for(int i=0; i<=5; i++)
        {
            System.out.println(employees[i]);
        }
    }
}
