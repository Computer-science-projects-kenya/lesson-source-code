/**
 * Created by Amuri on 3/28/2018.
 */
public class IfStatement2 {
    public static void main(String[] args)
    {
        int englishMarks,mathsMarks;
        englishMarks=10;
        mathsMarks=80;

        if(englishMarks<=50 && mathsMarks<=50)
        {
            System.out.println("You FAILED both English and Maths");
        }
        else if(englishMarks>50 && mathsMarks>50)
        {
            System.out.println("You PASSED both english and maths");
        }
        else if(englishMarks>50 && mathsMarks<=50 )
        {
            System.out.println("You PASSED english and FAILED maths");
        }
        else if(englishMarks>=80 || mathsMarks>=80 )
        {
            System.out.println("You have a DISTINCTION in one or both subjects");
        }

    }
}
