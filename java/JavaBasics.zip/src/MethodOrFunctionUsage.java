/**
 * Created by Amuri on 3/28/2018.
 */
public class MethodOrFunctionUsage {
    public static void main(String[] args)
    {
        int len=4;
        double wid=6.5;
        double answer;
        //lets call the method area() and pass variables len and wid
        answer=area(len,wid);
        //output the result
        System.out.println("The Area is"+answer);

        String name="Amuri";
        //lets call displayName() method and pass variable name
        displayName(name);

    }

    public static double area(int length, double width)
    {
        double result;
        result=length*width;
        return result;
    }
    //another method with No return type
    public static void displayName(String myName)
    {
        int age=10;
        System.out.println("Your name is "+myName+" Age "+age);
    }
}
